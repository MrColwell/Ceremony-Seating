gradSeating.exe organizes grads for SJHS graduation.

Sample files included in zip file: 
gradSeating.exe: Program that does the organizing
gradnames.txt: Sample list of names
gradsOrganized.txt: Sample list of output

INSTRUCTIONS:

Put all the names into a text file.
One name per line.
lastname, firstname
save the file as gradnames.txt
save the file in the same folder as gradSeating.exe
double click on gradSeating.exe
student lists will be written to gradsOrganized.txt

Have fun :)